# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2017 BroadTech IT Solutions Pvt Ltd 
#    (<http://broadtech-innovations.com>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import openerp
from openerp.modules.module import get_module_resource

from openerp import api, fields, models, _
from openerp import tools
from openerp.exceptions import ValidationError

class Visitor(models.Model):
    _name = 'bt.visitor'
    _description = "Visitor"
    
    @api.model
    def _get_default_image(self):
        image_path = get_module_resource('bt_visitor_log', 'static/src/img', 'default_image.png')
        return tools.image_resize_image_big(open(image_path, 'rb').read().encode('base64'))
    
    name = fields.Char('Name')
    street = fields.Char('Street')
    street2 = fields.Char('Street2')
    zip = fields.Char('Zip')
    city = fields.Char('City')
    state_id = fields.Many2one("res.country.state", string='State', ondelete='restrict')
    country_id = fields.Many2one('res.country', string='Country', ondelete='restrict')
    email = fields.Char('Email', copy=False)
    phone = fields.Char('Phone', copy=False)
    id_proof = fields.Char('ID Proof')
    id_proof_number = fields.Char('ID Proof Number', copy=False)
    image = fields.Binary("Image", attachment=True, default=_get_default_image, copy=False)
    image_medium = fields.Binary("Medium-sized image", attachment=True,
        help="Medium-sized image of this contact. It is automatically "\
             "resized as a 128x128px image, with aspect ratio preserved. "\
             "Use this field in form views or some kanban views.", copy=False, default=_get_default_image)
    image_small = fields.Binary("Small-sized image", attachment=True,
        help="Small-sized image of this contact. It is automatically "\
             "resized as a 64x64px image, with aspect ratio preserved. "\
             "Use this field anywhere a small image is required.", copy=False, default=_get_default_image)
    log_count = fields.Integer(compute="_compute_visit_logs", string='# of visit logs', copy=False, default=0)
    
    @api.multi
    def _compute_visit_logs(self):
        for visitor in self:
            visitor.log_count = self.env['bt.visitor.log'].search_count([('visitor_id','=',visitor.id)])
    
    @api.one
    @api.constrains('phone')
    def _check_amount(self):
        visitors = self.search_count([('phone','=',self.phone)])
        if visitors > 1:
            raise ValidationError(_('Phone number already exists for another visitor. Add new phone!'))
    
    @api.one
    @api.constrains('email')
    def _check_email(self):
        visitors = self.search_count([('email','=',self.email)])
        if visitors > 1:
            raise ValidationError(_('Email already exists for another visitor. Add new email!'))
    
    @api.model
    def create(self, vals):
        tools.image_resize_images(vals)
        return super(Visitor, self).create(vals)
    
    @api.multi
    def write(self, vals):
        tools.image_resize_images(vals)
        return super(Visitor, self).write(vals)
    
    @api.multi
    def action_schedule_visit(self):
        '''
        This function returns an action for creating visit logs.
        '''
        action = self.env.ref('bt_visitor_log.action_visitor_log')
        result = action.read()[0]
        result['context'] = {'default_visitor_id': self.id}

        res = self.env.ref('bt_visitor_log.view_visitor_log_form', False)
        result['views'] = [(res and res.id or False, 'form')]
        return result
    
    @api.multi
    def action_view_visit_log(self):
        '''
        This function returns an action that display existing visit logs of given visitor.
        '''
        action = self.env.ref('bt_visitor_log.action_visitor_log')
        result = action.read()[0]
        result['context'] = {'default_visitor_id': self.id}
        visitor_log_ids = self.env['bt.visitor.log'].search([('visitor_id','=',self.id)])
        #choose the view_mode accordingly
        if len(visitor_log_ids) != 1:
            result['domain'] = "[('id', 'in', " + str(visitor_log_ids.ids) + ")]"
        elif len(visitor_log_ids) == 1:
            res = self.env.ref('bt_visitor_log.view_visitor_log_form', False)
            result['views'] = [(res and res.id or False, 'form')]
            result['res_id'] = visitor_log_ids.id
        return result
    
        
# vim:expandtab:smartindent:tabstop=2:softtabstop=2:shiftwidth=2: