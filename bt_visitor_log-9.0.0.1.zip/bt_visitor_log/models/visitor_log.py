# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2017 BroadTech IT Solutions Pvt Ltd 
#    (<http://broadtech-innovations.com>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import api, fields, models
from datetime import datetime
from openerp.tools import DEFAULT_SERVER_DATETIME_FORMAT

class VisitorLog(models.Model):
    _name = 'bt.visitor.log'
    _description = "Visitor Log"
    
    name = fields.Char('Name')
    visitor_id = fields.Many2one('bt.visitor', 'Visitor')
    date = fields.Date('Date', default=fields.Date.context_today)
    employee_id = fields.Many2one('hr.employee', 'Person to Visit')
    time_in = fields.Datetime('Time In', default=lambda self: fields.Datetime.now(), copy=False)
    expected_time_out = fields.Datetime('Expected Time Out', copy=False)
    time_out = fields.Datetime('Time Out', copy=False)
    time_expire = fields.Boolean('Time Expire', copy=False)
    purpose = fields.Text('Purpose', copy=False)
    image = fields.Binary("Image", attachment=True, related='visitor_id.image')
    state = fields.Selection([('draft', 'Draft'), ('appointment', 'Appointment'),
                              ('in','IN'),('expired','Expired'),('out','OUT')], 
                             string='Status', copy=False, default='appointment')
    badgeid = fields.Char('Badge ID')
    
    @api.model
    def create(self, vals):
        seq = self.env['ir.sequence'].next_by_code('bt.visitor.log') or ''
        vals.update({'name': seq})
        res = super(VisitorLog, self).create(vals)
        return res
    
    @api.multi
    def action_set_in(self):
        for log in self:
            log.state = 'in'
            log.time_in = datetime.now()
        return True
    
    @api.multi
    def action_set_out(self):
        for log in self:
            log.state = 'out'
            log.time_out = datetime.now()
        return True
    
    @api.model
    def _check_visitor_logs(self):
        """ This Function is called by scheduler. """
        current_datetime = datetime.now()
        date_time_str = current_datetime.strftime(DEFAULT_SERVER_DATETIME_FORMAT)
        expired_logs = self.env['bt.visitor.log'].search([('state','=','in'),('expected_time_out','<=',date_time_str)])
        for visitor_log in expired_logs:
            visitor_log.state = 'expired'
            visitor_log.time_expire = True
        
# vim:expandtab:smartindent:tabstop=2:softtabstop=2:shiftwidth=2: