# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2017 BroadTech IT Solutions Pvt Ltd 
#    (<http://broadtech-innovations.com>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
{
    'name': 'Odoo Visitor Management',
    'version': '0.1',
    'category': 'custom',
    'summary': 'Odoo Visitor Management',
    'price': 10.00,   
    'currency': 'USD',
    'description': """
    Odoo visitor management is a simple solution to keep track of visitors inside an organization.
""",
    'author' : 'BroadTech IT Solutions Pvt Ltd',
    'website' : 'http://www.broadtech-innovations.com',
    'depends': ['hr'],
    'images': ['static/description/banner.jpg'],
    'data': [
        'security/visitor_security.xml',
        'security/ir.model.access.csv',
        'data/visitor_log_cron_data.xml',
        'views/visitor_log_sequence.xml',
        'views/visitor_view.xml',
        'views/visitor_log_view.xml',
        'views/visitor_badge_report.xml',
        'views/report.xml'
    ],
    'installable': True,
    'auto_install': False,
}

# vim:expandtab:smartindent:tabstop=2:softtabstop=2:shiftwidth=2: